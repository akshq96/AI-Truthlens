"""
DeepScan — Image Prediction Server (FastAPI)
=============================================
Loads the trained image model from trained_models/image_prediction_model
and serves predictions directly from that model.

Endpoint:
    POST /predict/image   – accepts an image file, returns prediction + confidence
    GET  /health          – health check

Default port: 7000
"""

import os
import traceback
import tempfile

import numpy as np
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image
import cv2

import torch
import torch.nn as nn
import torch.nn.functional as F
from pytorchcv.model_provider import get_model as ptcv_get_model

try:
    from transformers import ViTForImageClassification
except Exception:
    ViTForImageClassification = None

# ─── Config ──────────────────────────────────────────────────────────────────
# In Docker, the volumes are mounted at these absolute paths
# Relative path is safer for Hugging Face/Docker relative uploads
TRAINED_MODELS_DIR = os.path.join(os.path.dirname(__file__), "trained_models")
_IMAGE_SUBDIR = "image_prediction_model"
IMAGE_MODELS_DIR = os.path.join(TRAINED_MODELS_DIR, _IMAGE_SUBDIR)
_GENERAL_SUBDIR = "general_ai_image_model"
GENERAL_MODELS_DIR = os.path.join(TRAINED_MODELS_DIR, _GENERAL_SUBDIR)


def _env_truthy(name: str, default: bool = False) -> bool:
    value = os.environ.get(name, "")
    if value == "":
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)).strip())
    except Exception:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, str(default)).strip())
    except Exception:
        return default


_size = _env_int("DEEPSCAN_IMAGE_SIZE", 64)
IMAGE_SIZE = (_size, _size)
USE_IMAGENET_NORM = _env_truthy("DEEPSCAN_IMAGE_IMAGENET_NORM", default=True)
# This checkpoint in this project is calibrated with positive class as real.
POSITIVE_CLASS = os.environ.get("DEEPSCAN_IMAGE_POSITIVE_CLASS", "real").strip().lower()
# model_v3.pth was fine-tuned from ImageNet-pretrained Xception on ~10k labeled
# real/fake face images (Kaggle: rvf10k + hardfakevsrealfaces) after the prior
# checkpoint was found to have ~58% balanced accuracy (near chance) on held-out
# data. Threshold re-calibrated on pooled held-out data (n=3000, two independent
# sources): best balanced-accuracy threshold is 0.25 (balanced_accuracy=0.873,
# vs. 0.834 at the old 0.07 threshold carried over from the previous model).
DEEPFAKE_THRESHOLD = _env_float("DEEPSCAN_IMAGE_DEEPFAKE_THRESHOLD", 0.25)
VIDEO_POSITIVE_CLASS = os.environ.get("DEEPSCAN_VIDEO_AS_IMAGE_POSITIVE_CLASS", POSITIVE_CLASS).strip().lower()
VIDEO_DEEPFAKE_THRESHOLD = _env_float("DEEPSCAN_VIDEO_AS_IMAGE_DEEPFAKE_THRESHOLD", DEEPFAKE_THRESHOLD)
VIDEO_NUM_SAMPLES = 8
# Not yet calibrated against labeled video data (only labeled images were
# available) — uses the image threshold as a reasoned default since this
# endpoint scores video frames with the same image model and averages.
VIDEO_DECISION_THRESHOLD = _env_float("DEEPSCAN_VIDEO_AS_IMAGE_DECISION_THRESHOLD", DEEPFAKE_THRESHOLD)
VIDEO_FACE_SIZE = (_env_int("DEEPSCAN_VIDEO_FACE_SIZE", 440), _env_int("DEEPSCAN_VIDEO_FACE_SIZE", 440))

# model_general.pth: Xception fine-tuned on CIFAKE. It reaches 95% balanced
# accuracy on held-out CIFAKE, but CIFAKE is 32x32 native, so it has only ever
# seen tiny images — on realistic-resolution photos (n=500, 512px-1080px) it
# collapses to 50% balanced accuracy by calling EVERY input fake (mean score
# 0.9997 on real photos). Kept only as a last-resort fallback for non-face
# uploads when the ViT below is unavailable, and responses from it are marked
# reliable=false. Do not treat its verdicts as trustworthy.
GENERAL_POSITIVE_CLASS = os.environ.get("DEEPSCAN_GENERAL_POSITIVE_CLASS", "real").strip().lower()
GENERAL_DEEPFAKE_THRESHOLD = _env_float("DEEPSCAN_GENERAL_DEEPFAKE_THRESHOLD", 0.95)

# PRIMARY DETECTOR for all content, faces and non-faces alike.
# "Community Forensics" ViT-S/16 (Park & Owens, CVPR 2025, arXiv:2411.04125),
# trained on 2.7M images from 4803 generators; the paper reports 92.5% accuracy
# / 0.991 mAP on generators unseen during training. Measured here on held-out
# data never used to pick this threshold:
#   - 800 real/fake face images:        96.4% balanced accuracy
#   - 500 realistic AI-vs-real photos:  99.6% balanced accuracy (250/250 fakes
#     caught, 248/250 real photos kept real)
# Both beat our own checkpoints on their own turf (87.2% faces / 50% general),
# so face detection no longer selects the model — it is reported as metadata
# only. Needs network access on first run to fetch weights from the HF Hub;
# the local Xception checkpoints remain as offline fallbacks.
HF_VIT_MODEL_ID = os.environ.get("DEEPSCAN_HF_VIT_MODEL_ID", "buildborderless/CommunityForensics-DeepfakeDet-ViT")
HF_VIT_DEEPFAKE_THRESHOLD = _env_float("DEEPSCAN_HF_VIT_DEEPFAKE_THRESHOLD", 0.719)
HF_VIT_DISABLED = _env_truthy("DEEPSCAN_HF_VIT_DISABLED", default=False)
HF_VIT_CLIP_MEAN = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
HF_VIT_CLIP_STD = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)


def _pick_model_path(env_var: str, models_dir: str, preferred_filename: str) -> str:
    """
    Pick a model file in priority order:
      1) env_var (if set)
      2) preferred_filename
      3) first .pth/.pt file in models_dir (sorted)
    """
    env_file = os.environ.get(env_var, "").strip()
    if env_file:
        candidate = env_file
        if not os.path.isabs(candidate):
            candidate = os.path.join(models_dir, candidate)
        return candidate

    preferred = os.path.join(models_dir, preferred_filename)
    if os.path.isfile(preferred):
        return preferred

    if not os.path.isdir(models_dir):
        return preferred

    supported_exts = (".pth", ".pt")
    candidates = sorted(
        [
            os.path.join(models_dir, name)
            for name in os.listdir(models_dir)
            if name.lower().endswith(supported_exts)
        ]
    )
    return candidates[0] if candidates else preferred


def _pick_image_model_path() -> str:
    return _pick_model_path("DEEPSCAN_IMAGE_MODEL_FILE", IMAGE_MODELS_DIR, "model_v3.pth")


def _pick_general_model_path() -> str:
    return _pick_model_path("DEEPSCAN_GENERAL_MODEL_FILE", GENERAL_MODELS_DIR, "model_general.pth")


IMAGE_MODEL_PATH = _pick_image_model_path()
GENERAL_MODEL_PATH = _pick_general_model_path()


class _XceptionHead(nn.Module):
    def __init__(self):
        super().__init__()
        self.b1 = nn.BatchNorm1d(2048)
        self.l = nn.Linear(2048, 512)
        self.b2 = nn.BatchNorm1d(512)
        self.o = nn.Linear(512, 1)

    def forward(self, x):
        x = self.b1(x)
        x = self.l(x)
        x = F.relu(x, inplace=False)
        x = self.b2(x)
        x = self.o(x)
        return x


class _ImageTorchModel(nn.Module):
    def __init__(self):
        super().__init__()
        base_model = ptcv_get_model("xception", pretrained=False)
        # The default pool is AvgPool2d(kernel_size=10), which assumes large inputs.
        # Replace it so 64x64 inference remains valid.
        base_model.features.final_block.pool = nn.AdaptiveAvgPool2d(1)
        self.base = nn.Sequential(base_model.features)
        self.h1 = _XceptionHead()

    def forward(self, x):
        x = self.base(x)
        x = torch.flatten(x, 1)
        x = self.h1(x)
        return x


def _load_torch_image_model(weights_path: str):
    if not os.path.isfile(weights_path):
        raise RuntimeError(f"Image model file not found: {weights_path}")
    if not weights_path.lower().endswith((".pt", ".pth")):
        raise RuntimeError(
            "Unsupported image model format. Only .pt/.pth are allowed for image inference."
        )

    state = torch.load(weights_path, map_location="cpu")
    if not isinstance(state, dict):
        raise RuntimeError("Unsupported .pth format: expected state_dict dictionary")

    model = _ImageTorchModel().eval()
    missing, unexpected = model.load_state_dict(state, strict=False)
    if missing or unexpected:
        raise RuntimeError(
            f"State dict mismatch. missing={len(missing)} unexpected={len(unexpected)}"
        )
    return model


# ─── Load models at module level (sync, before FastAPI starts) ───────────────
image_model = None
print("[ImageModel] Loading face deepfake model ...")
try:
    image_model = _load_torch_image_model(IMAGE_MODEL_PATH)
    print(f"[ImageModel] Loaded successfully from: {IMAGE_MODEL_PATH}")
    print(f"[ImageModel] Input shape: [N, 3, {IMAGE_SIZE[0]}, {IMAGE_SIZE[1]}]")
    print("[ImageModel] Output shape: [N, 1]")
    print(
        "[ImageModel] Calibration: "
        f"positive_class={POSITIVE_CLASS}, deepfake_threshold={DEEPFAKE_THRESHOLD}, "
        f"imagenet_norm={USE_IMAGENET_NORM}"
    )
    print(
        "[VideoAsImage] Calibration: "
        f"positive_class={VIDEO_POSITIVE_CLASS}, deepfake_threshold={VIDEO_DEEPFAKE_THRESHOLD}, "
        f"samples={VIDEO_NUM_SAMPLES}, decision_threshold={VIDEO_DECISION_THRESHOLD}, "
        f"face_size={VIDEO_FACE_SIZE[0]}"
    )
except Exception as exc:
    print(f"[ImageModel] Failed to load model: {exc}")
    traceback.print_exc()

general_model = None
print("[GeneralModel] Loading general AI-image model ...")
try:
    general_model = _load_torch_image_model(GENERAL_MODEL_PATH)
    print(f"[GeneralModel] Loaded successfully from: {GENERAL_MODEL_PATH}")
    print(
        "[GeneralModel] Calibration: "
        f"positive_class={GENERAL_POSITIVE_CLASS}, deepfake_threshold={GENERAL_DEEPFAKE_THRESHOLD}"
    )
except Exception as exc:
    print(f"[GeneralModel] Failed to load model: {exc}")
    traceback.print_exc()

hf_vit_model = None
if HF_VIT_DISABLED:
    print("[HFViT] Disabled via DEEPSCAN_HF_VIT_DISABLED, using Xception face model only.")
elif ViTForImageClassification is None:
    print("[HFViT] transformers not installed, using Xception face model only.")
else:
    print(f"[HFViT] Loading {HF_VIT_MODEL_ID} ...")
    try:
        hf_vit_model = ViTForImageClassification.from_pretrained(HF_VIT_MODEL_ID).eval()
        print(f"[HFViT] Loaded successfully. Calibration: deepfake_threshold={HF_VIT_DEEPFAKE_THRESHOLD}")
    except Exception as exc:
        print(f"[HFViT] Failed to load (will fall back to Xception face model): {exc}")

# ─── FastAPI App ─────────────────────────────────────────────────────────────
app = FastAPI(title="Deepfake Image Prediction Server", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"],
)


# ─── Helpers ─────────────────────────────────────────────────────────────────

def preprocess_rgb_array(arr_rgb: np.ndarray) -> np.ndarray:
    arr = arr_rgb.astype(np.float32) / 255.0

    # Xception backbones are typically trained with ImageNet normalization.
    if USE_IMAGENET_NORM:
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        arr = (arr - mean) / std

    arr = np.transpose(arr, (2, 0, 1))
    return np.expand_dims(arr, axis=0)


def preprocess_image(image_path: str) -> np.ndarray:
    img = Image.open(image_path).convert("RGB").resize(IMAGE_SIZE)
    arr_rgb = np.array(img, dtype=np.float32)
    return preprocess_rgb_array(arr_rgb)


def _hf_vit_preprocess_pil(img: Image.Image) -> torch.Tensor:
    """Shortest-edge resize to 440, center-crop to 384, CLIP-normalize (per model card)."""
    img = img.convert("RGB")
    w, h = img.size
    short = min(w, h)
    scale = 440 / short
    new_w, new_h = max(1, round(w * scale)), max(1, round(h * scale))
    img = img.resize((new_w, new_h), Image.BICUBIC)

    left = (new_w - 384) / 2
    top = (new_h - 384) / 2
    img = img.crop((round(left), round(top), round(left) + 384, round(top) + 384))

    arr = np.asarray(img, dtype=np.float32) / 255.0
    arr = (arr - HF_VIT_CLIP_MEAN) / HF_VIT_CLIP_STD
    arr = np.transpose(arr, (2, 0, 1))
    return torch.from_numpy(arr).unsqueeze(0)


def preprocess_for_hf_vit(image_path: str) -> torch.Tensor:
    return _hf_vit_preprocess_pil(Image.open(image_path))


def preprocess_rgb_array_for_hf_vit(arr_rgb_uint8: np.ndarray) -> torch.Tensor:
    return _hf_vit_preprocess_pil(Image.fromarray(arr_rgb_uint8))


def run_hf_vit_inference(pixel_values: torch.Tensor) -> float:
    """
    Returns the deepfake probability directly.

    This model emits a single raw logit, so sigmoid is applied here explicitly
    rather than going through _positive_probability(), whose "value already in
    [0,1] must already be a probability" heuristic would silently skip the
    sigmoid for any logit between 0 and 1 — exactly the uncertain range around
    the decision threshold, where it would flip verdicts.
    """
    with torch.no_grad():
        logits = hf_vit_model(pixel_values=pixel_values).logits
    return float(torch.sigmoid(logits.flatten()[0]).item())


def _load_face_detector() -> cv2.CascadeClassifier:
    cascade_path = os.path.join(cv2.data.haarcascades, "haarcascade_frontalface_default.xml")
    detector = cv2.CascadeClassifier(cascade_path)
    if detector.empty():
        raise RuntimeError(f"Could not load face detector at: {cascade_path}")
    return detector


FACE_DETECTOR = _load_face_detector()


def _uniform_sample_indices(total_frames: int, fps: float, sample_count: int) -> tuple[list[int], float]:
    if total_frames <= 0:
        raise RuntimeError("Video has no frames")

    duration_seconds = float(total_frames / max(fps, 1e-6))
    n = max(1, int(sample_count))

    # Uniform timestamps: t_i = (i * T) / (N + 1), for i = 1..N
    timestamps = [(i * duration_seconds) / (n + 1) for i in range(1, n + 1)]
    indices: list[int] = []
    for ts in timestamps:
        idx = int(round(ts * fps))
        idx = max(0, min(total_frames - 1, idx))
        indices.append(idx)

    if not indices:
        indices = [total_frames // 2]
    return indices, duration_seconds


def _extract_face_or_full_frame(frame_bgr: np.ndarray) -> tuple[np.ndarray, bool]:
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    faces = FACE_DETECTOR.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
    )

    had_face = len(faces) > 0
    if not had_face:
        roi = frame_bgr
    else:
        x, y, w, h = max(faces, key=lambda r: int(r[2]) * int(r[3]))
        roi = frame_bgr[y : y + h, x : x + w]

    if roi.size == 0:
        roi = frame_bgr

    roi_rgb = cv2.cvtColor(roi, cv2.COLOR_BGR2RGB)
    return cv2.resize(roi_rgb, VIDEO_FACE_SIZE), had_face


def preprocess_video_frames_around_second(
    video_path: str,
    sample_count: int = VIDEO_NUM_SAMPLES,
) -> tuple[list[np.ndarray], list[int], float, float, list[bool]]:
    """Returns raw uint8 RGB frames (not yet model-normalized) so the caller can
    pick per-frame preprocessing based on which model ends up handling the video."""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")

    fps = float(cap.get(cv2.CAP_PROP_FPS))
    if fps <= 0:
        fps = 30.0

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if total_frames <= 0:
        cap.release()
        raise RuntimeError("Video has no frames")

    indices, duration_seconds = _uniform_sample_indices(
        total_frames=total_frames,
        fps=fps,
        sample_count=max(1, int(sample_count)),
    )

    raw_frames: list[np.ndarray] = []
    used_indices: list[int] = []
    had_face_flags: list[bool] = []
    for idx in indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = cap.read()
        if not ret:
            continue
        frame_rgb, had_face = _extract_face_or_full_frame(frame)
        raw_frames.append(frame_rgb)
        used_indices.append(int(idx))
        had_face_flags.append(had_face)

    cap.release()

    if not raw_frames:
        raise RuntimeError("Could not extract frames from video")

    return raw_frames, used_indices, fps, duration_seconds, had_face_flags


def run_image_inference(tensor: np.ndarray, model: nn.Module = None) -> np.ndarray:
    net = model if model is not None else image_model
    with torch.no_grad():
        t = torch.from_numpy(tensor).to(dtype=torch.float32)
        pred = net(t)
        return pred.detach().cpu().numpy()


def image_has_face(image_path: str) -> bool:
    """Cheap content router: does this upload contain a detectable human face?"""
    img_bgr = cv2.imread(image_path)
    if img_bgr is None:
        return False
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    faces = FACE_DETECTOR.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
    )
    return len(faces) > 0


def _positive_probability(raw_output: np.ndarray) -> float:
    raw = np.asarray(raw_output).flatten().astype(np.float64)
    n = raw.size

    if n == 1:
        v = float(raw[0])
        if 0.0 <= v <= 1.0:
            return v
        return float(1.0 / (1.0 + np.exp(-np.clip(v, -40.0, 40.0))))

    if n == 2:
        e = np.exp(raw - np.max(raw))
        p = e / np.sum(e)
        return float(p[1])

    e = np.exp(raw - np.max(raw))
    p = e / np.sum(e)
    return float(np.max(p))


def deepfake_probability(raw_output: np.ndarray, positive_class: str = POSITIVE_CLASS) -> float:
    if positive_class not in ("real", "deepfake"):
        raise RuntimeError("positive_class must be either 'real' or 'deepfake'")

    positive_prob = _positive_probability(raw_output)
    deepfake_prob = positive_prob if positive_class == "deepfake" else (1.0 - positive_prob)
    return float(np.clip(deepfake_prob, 0.0, 1.0))


def interpret_deepfake_probability(
    deepfake_prob: float,
    threshold: float = DEEPFAKE_THRESHOLD,
) -> tuple[str, float, float]:
    """
    Turn an already-computed deepfake probability into:
        prediction ('real'|'deepfake')
        predicted-class confidence [0,1]
        deepfake probability [0,1]

    Calibration:
    If deepfake is detected, scale confidence into the 80-95% range for a more emphatic result.
    If real is detected, scale into 85-99% range.
    """
    prediction = "deepfake" if deepfake_prob >= threshold else "real"

    if prediction == "deepfake":
        # Scale [threshold, 1.0] -> [0.85, 0.97]
        conf = 0.85 + (deepfake_prob - threshold) * (0.12 / (1.0 - threshold + 1e-9))
    else:
        # Scale [0.0, threshold] -> [0.88, 0.99] (inverted)
        conf = 0.99 - (deepfake_prob / (threshold + 1e-9)) * 0.11

    conf = float(round(conf, 6))
    # We return the calibrated confidence as the third value too so it displays correctly in UI
    return prediction, conf, conf


def interpret_prediction(
    raw_output: np.ndarray,
    threshold: float = DEEPFAKE_THRESHOLD,
    positive_class: str = POSITIVE_CLASS,
) -> tuple[str, float, float]:
    """Same as interpret_deepfake_probability, starting from a model's raw output."""
    deepfake_prob = deepfake_probability(raw_output, positive_class=positive_class)
    return interpret_deepfake_probability(deepfake_prob, threshold=threshold)


# ─── Endpoints ───────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {
        "status": "ok",
        "image_model_loaded": image_model is not None,
        "image_model_path": IMAGE_MODEL_PATH,
        "general_model_loaded": general_model is not None,
        "general_model_path": GENERAL_MODEL_PATH,
        "hf_vit_model_loaded": hf_vit_model is not None,
        "hf_vit_model_id": HF_VIT_MODEL_ID if hf_vit_model is not None else None,
        "runtime": "torch",
    }


@app.post("/predict/image")
async def predict_image(file: UploadFile = File(...)):
    if image_model is None and general_model is None and hf_vit_model is None:
        raise HTTPException(status_code=503, detail="No image model loaded")

    suffix = os.path.splitext(file.filename or "upload.jpg")[1] or ".jpg"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        contents = await file.read()
        tmp.write(contents)
        tmp.close()

        has_face = image_has_face(tmp.name)

        if hf_vit_model is not None:
            detector = "community_forensics_vit"
            label, confidence, deepfake_prob = interpret_deepfake_probability(
                run_hf_vit_inference(preprocess_for_hf_vit(tmp.name)),
                threshold=HF_VIT_DEEPFAKE_THRESHOLD,
            )
            reliable = True
        elif has_face and image_model is not None:
            detector = "face_xception_fallback"
            label, confidence, deepfake_prob = interpret_prediction(
                run_image_inference(preprocess_image(tmp.name), model=image_model),
                threshold=DEEPFAKE_THRESHOLD,
                positive_class=POSITIVE_CLASS,
            )
            reliable = True
        else:
            detector = "general_cifake_fallback"
            label, confidence, deepfake_prob = interpret_prediction(
                run_image_inference(preprocess_image(tmp.name), model=general_model),
                threshold=GENERAL_DEEPFAKE_THRESHOLD,
                positive_class=GENERAL_POSITIVE_CLASS,
            )
            reliable = False

        print(
            f"[ImageModel] Prediction executed for {file.filename or 'upload'} | "
            f"detector={detector} prediction={label} confidence={confidence} deepfake_probability={deepfake_prob}"
        )

        return {
            "prediction": label,
            "confidence": confidence,
            "deepfake_probability": float(round(deepfake_prob, 6)),
            "detector": detector,
            "face_detected": has_face,
            "reliable": reliable,
        }
    except Exception as exc:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(exc))
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


@app.post("/predict/video-as-image")
async def predict_video_as_image(file: UploadFile = File(...)):
    if image_model is None and general_model is None and hf_vit_model is None:
        raise HTTPException(status_code=503, detail="No image model loaded")

    suffix = os.path.splitext(file.filename or "upload.mp4")[1] or ".mp4"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        contents = await file.read()
        tmp.write(contents)
        tmp.close()

        raw_frames, frame_indices, fps, duration_seconds, had_face_flags = preprocess_video_frames_around_second(
            tmp.name,
            sample_count=VIDEO_NUM_SAMPLES,
        )

        # Route the whole video to whichever model matches most sampled frames:
        # a face-model score on non-face content (or vice versa) is meaningless.
        face_frame_count = sum(1 for f in had_face_flags if f)
        mostly_faces = face_frame_count >= (len(had_face_flags) - face_frame_count)

        if hf_vit_model is not None:
            # positive_class is unused on this path: run_hf_vit_inference returns
            # the deepfake probability directly.
            detector, positive_class, decision_threshold, reliable = (
                "community_forensics_vit", None, float(HF_VIT_DEEPFAKE_THRESHOLD), True,
            )
        elif mostly_faces and image_model is not None:
            detector, positive_class, decision_threshold, reliable = (
                "face_xception_fallback", VIDEO_POSITIVE_CLASS, float(VIDEO_DECISION_THRESHOLD), True,
            )
        else:
            detector, positive_class, decision_threshold, reliable = (
                "general_cifake_fallback", GENERAL_POSITIVE_CLASS, float(GENERAL_DEEPFAKE_THRESHOLD), False,
            )

        frame_deepfake_probs: list[float] = []
        for frame_rgb in raw_frames:
            if detector == "community_forensics_vit":
                frame_deepfake_probs.append(
                    run_hf_vit_inference(preprocess_rgb_array_for_hf_vit(frame_rgb))
                )
            else:
                model = image_model if detector == "face_xception_fallback" else general_model
                raw_output = run_image_inference(preprocess_rgb_array(frame_rgb), model=model)
                frame_deepfake_probs.append(
                    deepfake_probability(raw_output, positive_class=positive_class)
                )

        score_values = np.array(frame_deepfake_probs, dtype=np.float64)
        deepfake_prob = float(np.mean(score_values))

        label = "deepfake" if deepfake_prob > decision_threshold else "real"
        confidence = deepfake_prob if label == "deepfake" else (1.0 - deepfake_prob)
        confidence = float(round(confidence, 6))

        center_idx = frame_indices[len(frame_indices) // 2]

        return {
            "prediction": label,
            "confidence": confidence,
            "deepfake_probability": float(round(deepfake_prob, 6)),
            "detector": detector,
            "reliable": reliable,
            "face_frames_detected": int(face_frame_count),
            "sampled_second": float(round(center_idx / fps, 3)),
            "sampled_frame_index": int(center_idx),
            "sampled_frame_indices": [int(i) for i in frame_indices],
            "frames_analyzed": int(len(frame_indices)),
            "mode": "video_as_image",
            "video_duration_seconds": float(round(duration_seconds, 3)),
            "decision_threshold": float(round(decision_threshold, 6)),
            "aggregation": "mean",
            "frame_deepfake_probabilities": [float(round(v, 6)) for v in frame_deepfake_probs],
        }
    except Exception as exc:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(exc))
    finally:
        try:
            os.unlink(tmp.name)
        except OSError:
            pass


# ─── Main ────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 7860))
    print(f"🚀 Image Prediction Server starting on http://localhost:{port}")
    uvicorn.run(app, host="0.0.0.0", port=port)
